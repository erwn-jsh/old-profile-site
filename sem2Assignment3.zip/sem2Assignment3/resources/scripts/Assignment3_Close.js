window.onload = function() {
    var variable = setTimeout(function () {
        self.close(); 
    }, 5000);
}